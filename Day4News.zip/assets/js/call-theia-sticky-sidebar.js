$(document).ready(function() {
"use strict";
$('.col-md-8, .sidebar')
.theiaStickySidebar({
additionalMarginTop: 1
});
});